<?php
include '../includes/header.php';
$get_all_user = get_all_user();
$count = count($get_all_user);
include('../includes/pagination.php');
$records=array_slice($get_all_user,$start,$limit);
?>
<div class="page  has-sidebar-left height-full">
    <header class="blue accent-3 relative">
        <div class="container-fluid text-white">
            <div class="row p-t-b-10 ">
                <div class="col">
                    <h4>
                        <i class="icon-users"></i>
                        Users
                    </h4>
                </div>
            </div>
        </div>
    </header>
    <div class="container-fluid animatedParent animateOnce">
        <div class="tab-content my-3" id="v-pills-tabContent">
            <div class="tab-pane animated fadeInUpShort show active" id="v-pills-all" role="tabpanel" aria-labelledby="v-pills-all-tab">
                <div class="row my-3">
                    <div class="col-md-12">
                        <div class="card r-0 shadow">
                            <div class="table-responsive">
                                <form>
                                    <table class="table table-striped table-hover r-0">
                                        <thead>
                                        <tr class="no-b">
                                             <th>SNo</th>
                                            <th>First Name</th>
                                            <th>Last Name</th>
                                            <th>Email</th>
                                            <!-- <th>Image</th> -->
                                            <th>Phone No.</th>
                                            <th>Address</th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                        <?php foreach ($records as $key) 
                                        {
                                            // var_dump($key);
                                            $s_num = $key['s_num'];
                                            $user_id = $key['user_id'];
                                            $firstname = $key['firstname'];
                                            $lastname=$key['lastname'];
                                            $email = $key['email'];
                                            $profile_pic = $key['profile_pic'];
                                            $phone = $key['phone'];
                                            $detail=get_billing_detail_by_user_id($user_id);
                                            if($detail[0]['street'])
                                            {
                                            $Address=$detail[0]['street'].','.$detail[0]['postcode'];
                                            }
                                            else{
                                            $Address="N/A";   
                                            }
                                           
                                            ?>
                                            <tr>
                                                <td><?php echo $s_num;?></td>
                                                <td><?php echo $firstname;?></td>
                                                <td><?php echo $lastname;?></td>
                                                <td><?php echo $email;?></td>
                                               
                                                <td><?php echo $phone;?></td>
                                                 <td><?php echo $Address;?></td>
                                            </tr>
                                            <?php
                                        }
                                        ?>                                          
                                        </tbody>
                                    </table>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <nav class="my-3" aria-label="Page navigation" style="display: flex;justify-content: center;">
                    <ul class="pagination">
                        <?php echo $pagination;?>
                        <!-- <li class="page-item"><a class="page-link" href="#">Previous</a>
                        </li>
                        <li class="page-item"><a class="page-link" href="#">1</a>
                        </li>
                        <li class="page-item"><a class="page-link" href="#">2</a>
                        </li>
                        <li class="page-item"><a class="page-link" href="#">3</a>
                        </li>
                        <li class="page-item"><a class="page-link" href="#">Next</a>
                        </li> -->
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>
<?php
include '../includes/footer.php';
?>