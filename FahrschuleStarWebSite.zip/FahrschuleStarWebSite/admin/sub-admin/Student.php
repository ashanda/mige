<?php
include 'header.php';
$current_time=time();
$id=$_SESSION['id'];
$cid=$_REQUEST['course_id'];
$get_all_courses =  get_billing_course_detail($cid);
// var_dump($get_all_courses);
// $attendance_detail=get_student_attendance_detail_by_course_id($cid,$get_all_courses[0]['user_id']);
// var_dump($attendance_detail);
$count = count($get_all_courses);
include('../includes/pagination.php');
$records=array_slice($get_all_courses, $start,$limit);

?>
<style type="text/css">
  /*.stuid{
  display: inline;
  color:black;
  position: relative;
  top:200px;
}*/

/*.stuid:hover:after{
    background: grey;
    border-radius: 5px;
    color: #fff;
    content: attr(title);
    left: 20%;
    padding: 5px 15px;
    position: absolute;
    top: -53px;
    width: 163px;
}*/

/*.stuid:hover:before{
  border:solid;
  border-color: #333 transparent;
  border-width: 6px 6px 0px 6px;
  bottom: 20px;
  content: "";
  left: 50%;
  position: absolute;
  z-index: 99;
}*/
</style>
<div class="page  has-sidebar-left height-full">
    <header class="blue accent-3 relative">
        <div class="container-fluid text-white">
            <div class="row p-t-b-10 ">
                <div class="col">
                    <h4>
                        <i class="icon-th-list"></i>
                       Student Detail
                    </h4>
                </div>
            </div>
           
    </header>
    <div class="container-fluid animatedParent animateOnce">
        <div class="tab-content my-3" id="v-pills-tabContent">
            <div class="tab-pane animated fadeInUpShort show active" id="v-pills-all" role="tabpanel" aria-labelledby="v-pills-all-tab">
                <div class="row my-3">
                    <div class="col-md-12">
                        <div class="card r-0 shadow">
                            <div class="table-responsive">
                                <form>
                                    <table class="table table-striped table-hover r-0">
                                        <thead>
                                        <tr class="no-b">
                                             <th>SNo</th>
                                             <th>Student Name</th>
                                             <th>Phone No.</th>
                                             <th>Total Price</th>
                                             <th>Payment Type</th>
                                             <th>Payment Status</th>
                                             <th>Attendance</th>
                                            
                                            <!-- <th>Number Of Slots</th> -->
                                            <th>Action</th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                        <?php foreach ($records as $key) 
                                        {
                                            $s_num = $key['s_num'];
                                            $attendance_detail=get_student_attendance_detail_by_course_id($cid,$key['user_id']);
                                        ?>

                                            <tr class="user_detail" >
                                            <!-- <input type="hidden" id="stuid" value="<?php echo $key['id'];?>"> -->
                                               <td><?php echo $s_num;?></td>
                                                 <!-- <td><?php echo $key['user_id'];?></td> -->
                                               <td><?php echo $key['firstname'].' '. $key['lastname'] ;?></td>
                                               <td><?php echo $key['phone'];?></td>
                                               <td><?php echo $key['total_price'];?></td>
                                               <td><?php echo $key['payment_type'];?></td>
                                               <td><?php if($key['payment_status']==0) {echo "pending";} elseif($key['payment_status']==1){echo "paid";}?></td> 
                                               <td><?php if($attendance_detail[0]['attendance_status']==0) {echo "--";} elseif($attendance_detail[0]['attendance_status']==1){echo "Present";}elseif($attendance_detail[0]['attendance_status']==2){echo "Absent";}?></td> 
                                              
                                               <td><button type="button" title="Payment."  data-toggle="modal" data-target="#myModal" class="stuid" id="<?php echo $key['id'];?>"><i class="icon icon-payment"></i></button>
                                                <button type="button" title="Attendance." data-toggle="modal" data-target="#attendanceModal" class="user_id" id="<?php echo $key['user_id'];?>"><i class="icon icon-check"></i></button></td> 
                                            </tr>
                                            <?php
                                        }
                                        ?>                                        
                                        </tbody>
                                    </table>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <nav class="my-3" aria-label="Page navigation" style="display: flex;justify-content: center;">
                    <ul class="pagination">
                        <?php echo $pagination;?>
                      
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>


<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
         <h4 class="modal-title">Edit Payment Status</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
       
      </div>
      <div class="modal-body">
        <form method="post">
           <input type="hidden"  id="test4">
       <p style="color: black">Select Payment Status: </p>
        Paid <input type="radio" name="payment_status" id="payment_status" value="1">
        Pending <input type="radio" name="payment_status" id="payment_status" value="0">
     
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary btn-lg" id="submitBtn" data-dismiss="modal">Submit</button>
      </div>
    </div>

  </div>
</div>


<div id="attendanceModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
         <h4 class="modal-title">Edit Student Attendance</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
       
      </div>
      <div class="modal-body">
        <form method="post">
          <input type="hidden" name="user_id" id="test3">
       <p style="color: black">Mark Attendance: </p>
        Present <input type="radio" name="attendance_status" id="attendance_status" value="1">
        Absent <input type="radio" name="attendance_status" id="attendance_status" value="2">
     
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary btn-lg" id="attendanceBtn" data-dismiss="modal">Submit</button>
      </div>
    </div>

  </div>
</div>
<?php
include '../includes/footer.php';
?>
<script type="text/javascript">
  
$(document).ready(function(){
   $('.stuid').click(function(){
    var user_id = $(this).attr('id');
    console.log("user_id"+user_id);
      $("#test4").val(user_id);
  });
    $("#submitBtn").on('click', function(){
        var payment_status = $("input[name='payment_status']:checked").val();
        var booked_id = $('#test4').val();
         $.ajax({
           url: 'EditPayment.php',
           type: 'POST',
           data: {payment_status: payment_status,booked_id:booked_id,type:1},
           
           success: function(data) {
       console.log(data);
            if(data==1){
                  location.reload();  
                alert('payment status update successfully!');

            }
            else{
                alert('Something went wrong!')
            }
            }
            })
    });
});

$(document).ready(function(){
  $('.user_id').click(function(){
    var user_id = $(this).attr('id');
    console.log("user_id"+user_id);
      $("#test3").val(user_id);
  });
    $("#attendanceBtn").on('click', function(){
        var attendance_status = $("input[name='attendance_status']:checked").val();
        var course_id = '<?php echo $_REQUEST['course_id'];?>';
        // var student_id = '<?php //echo $get_all_courses[0]['user_id'];?>';
        var student_id = $('#test3').val();
        // alert(student_id);
         $.ajax({
           url: 'EditPayment.php',
           type: 'POST',
           data: {attendance_status: attendance_status,course_id:course_id,student_id:student_id,type:2},
           
           success: function(data) {
         console.log(data);
            if(data==1){
                  location.reload();  
                alert('Attendance marked successfully!');

            }
            else{
                alert('Something went wrong!')
            }
            }
            })
    });
});
</script>