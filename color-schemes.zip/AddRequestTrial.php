<?php 
include 'Config/Connection.php';
include 'Functions.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require '../mail/autoload.php';
$name=$_POST['name'];
$email=$_POST['email'];
$dob=$_POST['dob'];
$phone_no=$_POST['phone_no'];
$trial_lesson=$_POST['trial_lesson'];
$trial_category=$_POST['trial_category'];
$trial_time_slot=$_POST['trial_time_slot'];
$trial_weekday=$_POST['trial_weekday'];
$message=$_POST['message'];

if($name=="")
{
echo json_encode(array('message'=>'Please enter name.'));
}
elseif($email=="")
{
echo json_encode(array('message'=>'Please enter email.'));
}
elseif($dob=="")
{
echo json_encode(array('message'=>'Please select date of birth.'));
}
elseif($phone_no=="")
{
echo json_encode(array('message'=>'Please enter phone number.'));
}
elseif(strlen($phone_no)!='10')
{
echo json_encode(array('message'=>'Please enter valid phone number.'));
}
elseif($trial_lesson=="")
{
echo json_encode(array('message'=>'Please select lesson.'));
}
elseif($trial_category=="")
{
echo json_encode(array('message'=>'Please select category.'));
}
elseif($trial_time_slot=="")
{
echo json_encode(array('message'=>'Please select available time.'));
}
elseif($trial_weekday=="")
{
echo json_encode(array('message'=>'Please select weekly day.'));
}
elseif($message=="")
{
echo json_encode(array('message'=>'Please enter message.'));
}

else{
// die();
	// var_dump($trial_time_slot);
$trial_lesson_value_detail=get_trial_lesson_detail_by_id($trial_lesson);
$trial_lesson_value=$trial_lesson_value_detail[0]['name'];
$trial_category_value_detail=get_trial_category_detail_by_id($trial_category);
$trial_category_value=$trial_category_value_detail[0]['name'];
	$course_id_arrayss = explode(',', $trial_time_slot);
	// var_dump($trial_lesson_value);
	// var_dump($trial_category_value);
foreach ($trial_time_slot as $key => $value) {
$trial_time_slot_value_detail=get_trial_time_slot_detail_by_id($value['id']);
$trial_time_slot_value[]=$trial_time_slot_value_detail[0]['day'].'('.$trial_time_slot_value_detail[0]['start_time'].'-'.$trial_time_slot_value_detail[0]['end_time'].')';

}
$trial_time_slot_values=implode(',', $trial_time_slot_value);
foreach ($trial_weekday as $key => $value) {
$trial_weekday_value_detail=get_trial_weekday_detail_by_id($value['id']);
$trial_weekday_value[]=$trial_weekday_value_detail[0]['week_name'];

}
$trial_weekday_value=implode(',', $trial_weekday_value);
// var_dump($trial_time_slot_value);

// $trial_time_slot_value_detail=get_trial_time_slot_detail_by_id($id);
$trial_time_slot_value=$trial_time_slot_value_detail[0]['date'].'('.$trial_time_slot_value_detail[0]['start_time'].'-'.$trial_time_slot_value_detail[0]['end_time'.''];
$weekdays=implode(',', $trial_weekday);
// var_dump($weekday);
$time_slots=implode(',', $trial_time_slot);
// var_dump($weekday);


	$add_request=create_request_trial_lesson($name,$email,$dob,$phone_no,$trial_lesson,$trial_category,$time_slots,$weekdays,$message);
	if($add_request){
		$request_id=$conn->insert_id;
		 // $email=$user_detail[0]['email'];
            // var_dump($email);
		$recipients = array(
"dharmaniz.komal@gmail.com",
$trial_lesson_value_detail[0]['email'],
);
		// $email_to = implode(',', $recipients); 
		
		foreach ($recipients as $key => $value) {
	
		 $to = $value;
       
        $subject = "Request A Trial Lesson Now";
        
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        
        $headers .= "From: support@dharmani.com";

        $email_message = 'You have received a new Trial Lesson request. Here are the details:
		Name: '.$name.'<br>
		Email: '.$email.'<br>
		Dob: '.$dob.'<br>
		Phone No.: '.$phone_no.'<br>
		Trail lesson: '.$trial_lesson_value.'<br>
		Trial category: '.$trial_category_value.'<br>
		Available Time: '.$trial_time_slot_values.'<br>
		Weekdays: '.$trial_weekday_value.'<br>
		Message: '.$message.'<br>
		';

        $success = mail($to,$subject,$email_message,$headers);
        		# code...
		}
		
		    if($success)
		    {
		    	// Return Success - Valid Emailur email
		    	$msg = 'Your request have been submitted. ';
		    	//http_response_code(401);
				$json_message = array("status"=>1,"message"=>$msg,'mail'=>$success,'color'=>'green');
				send_response($json_message);
				exit;
		    }
		    else
		    {
		    	echo json_encode(array('status'=>0,'message'=>'Failed to send mail','success'=>$e,'color'=>'red'));
		  		exit();
		    }
		    
	
	}
}