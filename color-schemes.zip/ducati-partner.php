<?php include 'header.php';?>
            <!--/Menu-->

            <!--About-->

	<div id="loader-container">
		<div class="loader-content">
			<div class="loader">Loading...</div>
		</div>
	</div>
	<div class="no-padding">
		<section class="banner-ducati">
			<div class="container">
				<h2>Ducati partner</h2>
            </div>
		</section>
		<section class="team" style="padding-bottom: 50px; background:#f2f2f2;">
			<div class="container">
				<div class="row main-cont-box">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="about-page-text">
							<h4 class="about-small-ducati">As an official Ducati partner, we guarantee the highest quality</h4>
							<h4 class="about-small-du-2">The history of Ducati</h4>
							<p>Borgo Panigale, once a settlement of farms and tenants' houses, is now located in a district in western Bologna. It became known with the founding of the brothers Adriano, Bruno and Marcello Cavalieri Ducati in 1935.</p>
							<p>Since 1946 the massive work has been considered the "cradle" of the Reds from Borgo Panigale. However, the origins of the Ducati are not to be found in Borgo Panigale.</p>
						</div>
					</div>
				</div>
			</div>
		</section>
		<section class="course-video" style="background:#fff;">
			<div class="container">
				<div class="row animatedParent">
					<div class="col-md-8 text-side-mobile-img">
						<p>Not many know that Ducati was initially based in the middle of Bologna. Società Scientifica Radio Brevetti Ducati (the company's original name) was founded on July 4, 1926 and the company's headquarters were in the middle of Bologna's old town, at Via Collegio di Spagna 9, where it was adjacent to the institute of the same name.</p>
						<p>At that time, the three brothers rented three rooms on the ground floor in which they started their work. The actual work was in the basement of the villa owned by the Ducati family at Viale Guidotti 51.</p>
					</div>
					<div class="col-md-4 phone-image-logo2wj"> <img src="images/ducati-n12.png"> </div>
				</div>
			</div>
		</section>
		<section class="rentbike">
			<div class="container">
				<div class="row animatedParent">
					<div class="col-md-3 t-center"> <img src="images/Partner_Hauptlin.png"> </div>
					<div class="col-md-9">
						<h4 class="about-small-ducati">The driving instructors for Ducati drivers</h3>
						<p>Being an official driving school partner of Ducati means responsibility and quality standards. We are competent driving instructors, both pedagogically and professionally.</p>
						<p><b>We hope you enjoy driving!</b></p>
					</div>
				</div>
			</div>
		</section>
	</div>
	<!-- /Main content -->
	<?php
include 'footer.php';
?>