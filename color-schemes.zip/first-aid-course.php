<?php include 'header.php';?>
            <!--/Menu-->
            <style type="text/css">
				div#main
				{
					padding-top:85px !important;
				}
				div#google_translate_element {
					display: none;
				}
				@media (max-width: 768px){
				div#main {
					padding-top: 62px !important;
				}
				}
				</style>
            <!--About-->
            <section class="banner" id="first-aid-box">
                <div class="container"><h2><?php echo $translation['First _Aid _Course_Title_']?></h2></div>
            </section>
            <section class="team" style="padding-bottom: 50px; background:#f2f2f2;">
                <div class="container">
                    <div class="row main-cont-box">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="about-page-text">
                                <h4 class="about-small" style="color:#e90616;"><?php echo $translation['_First_Aid_Course_Aargau_Title_']?></h4>
                                <p><?php echo $translation['We_offer_the_first_aid_title_ ']?></p>
                                <p><?php echo $translation['_Study_Show_Over_title_']?></p>
                                <p><?php echo $translation['_Aid_course_prerequisite_title_']?></p>
                            </div>
							<div class="service-video animatedParent">
								<iframe class="animated fadeInLeft slow go" src="https://www.youtube.com/embed/uLESrpuNsIs?autoplay=1&amp;feature=oembed" width="100%" height="550px" frameborder="0" allowfullscreen="1" allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"></iframe>
							</div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="course-video">
				<div class="container">
					<div class="row animatedParent">
						<div class="col-md-7 text-side-mobile-img animated bounceInLeft slow">
							<p><?php echo $translation['_ dusty_ first_ aid_ course_Title_']?></p>
							<p>
								<?php echo $translation['_learn_how_to_provide_title_']?>
							</p>
							<p><?php echo $translation['_we_Say_title_']?></p>
							<p><?php echo $translation['_if_you_taking_course_title_']?></p>
							<p style="margin-top: 20px; margin-bottom: 20px;"><img src="images/appstore_logo.png" /> <img src="images/google-play-store-logo.png" /></p>
							<p>
								<b>Important:</b><?php echo $translation['_Important_Title_']?>  <a href="#"><b>info@ucademy.ch</b></a>
							</p>
						</div>
						<div class="col-md-5 phone-image animated bounceInRight slow">
							<img src="images/ucademy-3D-animation-low.gif" />
						</div>
					</div>
				</div>
            </section>
            <section class="animatedParent service-form-bot" style="background: #e90616;">
				<div class="container">
					<img class="animated bounceInLeft slow" src="images/uss-img.png" style="width: 100%;" />
					<div class="row form-bokking animated bounceInRight slow">
						<div class="col-md-9">
							<h3 style="margin-top: 30px; color: #fff;"><?php echo $translation['_first _aid _course_ online_Title_']?></h3>
							<p style="color: #fff;"><?php echo $translation['_easily_online_title_']?>.</p>
						</div>
						<div class="col-md-3 btn-side-form"><a href="registration-form.php"><button type="submit" class="btn-primary book-on-red"><?php echo $translation['_submit_title_']?></button></a></div>
					</div>
				</div>
            </section>
            <!--Services list-->
        </div>
        <!-- /Main content -->

<?php
include 'footer.php';
?>